﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TDRS.DAL;
using TDRS.Entity;
using TDRS.Exceptions;
using System.Text.RegularExpressions;
namespace TDRS.BL
{
    public class TDRSValidations
    {
        private static bool TDRSValidation(NewRecharge138314 r)
        {
            bool rValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                if (r.NewConsumer138314Mobile_Number.ToString() == string.Empty)
                {
                    message.Append("Mobile no should be provided\n");
                    rValidated = false;
                }




                else if (!Regex.IsMatch(r.NewConsumer138314Mobile_Number.ToString(), "[0-9]{10}"))
                {
                    message.Append("Mobile no should have 10 digits");
                    rValidated = false;
                }

                if (rValidated == false)
                    throw new TDRSException(message.ToString());
            }
            catch (TDRSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rValidated;
        }

        public static int AddRecharge(NewRecharge138314 r)
        {
            int records = 0;
            try
            {
                if (TDRSValidation(r))
                {
                    records = TDRSOperations.AddRecharge(r);
                }
                else
                    throw new TDRSException("Provide valid information");
            }
            catch(TDRSException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }


            return records;
            }

        public static NewConsumer138314 SearchConsumer(Int64 m)
        {
            NewConsumer138314 con=null;
            try
            {
                con = TDRSOperations.SearchConsumer(m);
                if (con == null)
                    throw new TDRSException("Invalid user");
            }
            catch(TDRSException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return con;


        }
    }
}
