﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDRS.Exceptions
{
    public class TDRSException:ApplicationException

    {
        public TDRSException():base()
        {

        }
        public TDRSException(string message)
            : base(message)
        {

        }
    }
}
