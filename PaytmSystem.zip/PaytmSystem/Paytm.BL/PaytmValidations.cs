﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paytm.Entity;
using Paytm.Exception;
using Paytm.DAL;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Paytm.BL
{
    public class PaytmValidations
    {
        private static bool PaytmValidation(RechargeDetails_138251 stud)
        {
            bool studValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                if (stud.Mobile_Number.Trim() == String.Empty)
                {
                    message.Append("Mobile no should be provided\n");
                    studValidated = false;
                }




                else if (!Regex.IsMatch(stud.Mobile_Number, "[0-9]{10}"))
                {
                    message.Append("Mobile no should have 10 digits");
                    studValidated = false;
                }

                if (studValidated == false)
                    throw new PaytmException(message.ToString());
            }
            catch (PaytmException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }


        public static int AddRecharge(RechargeDetails_138251 stud)
        {
            int records = 0;

            try
            {
                if (PaytmValidation(stud))
                {
                    records = PaytmOperations.AddRecharge(stud);
                }
                else
                    throw new PaytmException("Please provide valid information");
            }
            catch (PaytmException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        public static Consumer_138251 SearchConsumer(string scode)
        {
            Consumer_138251 stud = null;

            try
            {
                stud = PaytmOperations.SearchConsumer(scode);
            }
            catch (PaytmException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

    }
}
