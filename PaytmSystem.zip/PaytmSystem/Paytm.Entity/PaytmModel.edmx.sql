
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 11/14/2017 18:56:58
-- Generated from EDMX file: D:\Users\mnadim\Desktop\Demo1\PaytmSystem\Paytm.Entity\PaytmModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Training_20Sep17_Pune_Batch_II];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Consumer_138251'
CREATE TABLE [dbo].[Consumer_138251] (
    [Mobile_Number] bigint  NOT NULL,
    [Consumer_Name] nvarchar(max)  NOT NULL,
    [Region] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'RechargeDetails_138251'
CREATE TABLE [dbo].[RechargeDetails_138251] (
    [RechargeId] int IDENTITY(1,1) NOT NULL,
    [Amount] float  NOT NULL,
    [Validity] int  NOT NULL,
    [Talktime] nvarchar(max)  NOT NULL,
    [Data] nvarchar(max)  NOT NULL,
    [RechargedOn] datetime  NOT NULL,
    [ValidTillDate]  as (DATEADD(dd, Validity, RechargedOn)),
    [Mobile_Number] bigint  NOT NULL
);
GO
--Drop table RechargeDetails_138251
--Drop table Consumer_138251
-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Mobile_Number] in table 'Consumer_138251'
ALTER TABLE [dbo].[Consumer_138251]
ADD CONSTRAINT [PK_Consumer_138251]
    PRIMARY KEY CLUSTERED ([Mobile_Number] ASC);
GO

-- Creating primary key on [RechargeId] in table 'RechargeDetails_138251'
ALTER TABLE [dbo].[RechargeDetails_138251]
ADD CONSTRAINT [PK_RechargeDetails_138251]
    PRIMARY KEY CLUSTERED ([RechargeId] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Mobile_Number] in table 'RechargeDetails_138251'
ALTER TABLE [dbo].[RechargeDetails_138251]
ADD CONSTRAINT [FK_Consumer_138251RechargeDetails_138251]
    FOREIGN KEY ([Mobile_Number])
    REFERENCES [dbo].[Consumer_138251]
        ([Mobile_Number])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Consumer_138251RechargeDetails_138251'
CREATE INDEX [IX_FK_Consumer_138251RechargeDetails_138251]
ON [dbo].[RechargeDetails_138251]
    ([Mobile_Number]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------

