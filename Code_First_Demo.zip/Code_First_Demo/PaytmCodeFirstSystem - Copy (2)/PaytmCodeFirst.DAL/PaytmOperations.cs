﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PaytmCodeFirst.Entity;
using PaytmCodeFirst.Exception;

namespace PaytmCodeFirst.DAL
{
    public class PaytmOperations
    {
        static Context1 context1 = new Context1();

        public static int AddRecharge(Recharge_123 r)
        {
            int records = 0;

            try
            {
                context1.Recharge_123.Add(r);

                records = context1.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static Consumer_123 SearchConsumer(Int64 scode)
        {
            Consumer_123 stud = null;

            try
            {

                stud = (from s in context1.Consumer_123
                        where s.Mob_No == scode
                        select s).FirstOrDefault();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }
    }
}
