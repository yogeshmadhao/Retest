﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paytm.Entity;
using Paytm.Exception;
using Paytm.DAL;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Paytm.BL
{
    public class PaytmValidations
    {
        private static bool PaytmValidation(Recharge_138252 stud)
        {
            bool studValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                if (stud.Mobile_Number.ToString() == string.Empty)
                {
                    message.Append("Mobile no should be provided\n");
                    studValidated = false;
                }




                else if (!Regex.IsMatch(stud.Mobile_Number.ToString(), "[0-9]{10}"))
                {
                    message.Append("Mobile no should have 10 digits");
                    studValidated = false;
                }

                if (studValidated == false)
                    throw new PaytmException(message.ToString());
            }
            catch (PaytmException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }


        public static int AddRecharge(Recharge_138252 stud)
        {
            int records = 0;

            try
            {
                if (PaytmValidation(stud))
                {
                    records = PaytmOperations.AddRecharge(stud);
                }
                else
                    throw new PaytmException("Please provide valid information");
            }
            catch (PaytmException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        public static Consumer_138252 SearchConsumer(Int64 scode)
        {
            Consumer_138252 stud = null;

            try
            {
                stud = PaytmOperations.SearchConsumer(scode);
                if(stud==null)
                {
                    throw new PaytmException("Invalid user");
                }
            }
            catch (PaytmException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

    }
}
