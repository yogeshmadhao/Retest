﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PaytmCodeFirst.Entity;
using PaytmCodeFirst.Exception;
using PaytmCodeFirst.BL;

namespace PaytmCodeFirst.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnVerify_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Consumer_123 con = null;
                con = PaytmValidations.SearchConsumer(Convert.ToInt64(txtMobNo.Text));
                gridConsumer.DataContext = con; //binding datagrid with con object
                lbRecharge.Visibility = Visibility.Visible;
                btnRecharge.Visibility = Visibility.Visible;
            }
            catch (PaytmException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnRecharge_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int records = PaytmValidations.AddRecharge(r);

                if (records > 0)
                {
                    MessageBox.Show("Recharge successfull!");

                }
                else
                    throw new PaytmException("Record not added");
            }
            catch (PaytmException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        Recharge_123 r = new Recharge_123();

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {

            r.Amount = Convert.ToDouble(txtAmt.Text);
            r.Validity = Convert.ToInt32(txtVal.Text);
            r.Data = txtData.Text;
            r.Talktime = txtTalktime.Text;
            r.RechargeOn = DateTime.Today;
            r.ValidTillDate = DateTime.Today.AddMonths(254);
            r.Mob_No = Convert.ToInt64(txtMobNo.Text);


        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {

            r.Amount = Convert.ToDouble(txtAmt2.Text);
            r.Validity = Convert.ToInt32(txtVal2.Text);
            r.Data = txtData2.Text;
            r.Talktime = txtTalktime2.Text;
            r.RechargeOn = DateTime.Today;
            r.ValidTillDate = DateTime.Today.AddMonths(254);
            r.Mob_No = Convert.ToInt64(txtMobNo.Text);
        }
    }
}
