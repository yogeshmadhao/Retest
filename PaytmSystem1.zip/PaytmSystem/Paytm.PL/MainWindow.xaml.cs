﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Paytm.Entity;
using Paytm.Exception;
using Paytm.BL;

namespace Paytm.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void btnVerify_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Consumer_138252 con = null;
                con = PaytmValidations.SearchConsumer(Convert.ToInt64(txtMobNo.Text));
                gridConsumer.DataContext = con;
                lbRecharge.Visibility = Visibility.Visible;
                btnRecharge.Visibility = Visibility.Visible;
            }
            catch (PaytmException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnRecharge_Click(object sender, RoutedEventArgs e)
        {
            
        }

    }   
}
