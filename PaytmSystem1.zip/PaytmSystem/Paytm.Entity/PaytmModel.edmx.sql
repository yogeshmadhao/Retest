
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 11/15/2017 19:15:44
-- Generated from EDMX file: D:\Users\mnadim\Desktop\Demo1\PaytmSystem\Paytm.Entity\PaytmModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Training_20Sep17_Pune_Batch_II];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Consumer_138252'
CREATE TABLE [dbo].[Consumer_138252] (
    [Mobile_Number] bigint  NOT NULL,
    [Consumer_Name] nvarchar(max)  NOT NULL,
    [Region] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Recharge_138252'
CREATE TABLE [dbo].[Recharge_138252] (
    [Recharge_Id] int IDENTITY(1,1) NOT NULL,
    [Amount] float  NOT NULL,
    [Validity] int  NOT NULL,
    [Talktime] nvarchar(max)  NOT NULL,
    [Data] nvarchar(max)  NOT NULL,
    [RechargeOn] datetime  NOT NULL,
    [ValidTillDate]  as (DATEADD(dd, Validity, RechargeOn)),
    [Mobile_Number] bigint  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Mobile_Number] in table 'Consumer_138252'
ALTER TABLE [dbo].[Consumer_138252]
ADD CONSTRAINT [PK_Consumer_138252]
    PRIMARY KEY CLUSTERED ([Mobile_Number] ASC);
GO

-- Creating primary key on [Recharge_Id] in table 'Recharge_138252'
ALTER TABLE [dbo].[Recharge_138252]
ADD CONSTRAINT [PK_Recharge_138252]
    PRIMARY KEY CLUSTERED ([Recharge_Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Mobile_Number] in table 'Recharge_138252'
ALTER TABLE [dbo].[Recharge_138252]
ADD CONSTRAINT [FK_Consumer_138252Recharge_138252]
    FOREIGN KEY ([Mobile_Number])
    REFERENCES [dbo].[Consumer_138252]
        ([Mobile_Number])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Consumer_138252Recharge_138252'
CREATE INDEX [IX_FK_Consumer_138252Recharge_138252]
ON [dbo].[Recharge_138252]
    ([Mobile_Number]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------
--Drop table Consumer_138252
--Drop table Recharge_138252