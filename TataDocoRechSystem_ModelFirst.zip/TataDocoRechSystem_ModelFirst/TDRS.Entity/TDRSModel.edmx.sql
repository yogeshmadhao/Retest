
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 11/15/2017 15:02:35
-- Generated from EDMX file: D:\Users\yogote\Desktop\EXAM\TataDocoRechSystem\TDRS.Entity\TDRSModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Training_20Sep17_Pune_Batch_II];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'NewConsumer138314'
CREATE TABLE [dbo].[NewConsumer138314] (
    [Mobile_Number] bigint  NOT NULL,
    [Consumer_Name] nvarchar(max)  NOT NULL,
    [Region] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'NewRecharge138314'
CREATE TABLE [dbo].[NewRecharge138314] (
    [RechargeID] int IDENTITY(1,1) NOT NULL,
    [Amount] float  NOT NULL,
    [Validity] int  NOT NULL,
    [TalkTime] nvarchar(max)  NOT NULL,
    [Data] nvarchar(max)  NOT NULL,
    [RechargedOn] datetime  NOT NULL,
    [ValidTillDate]  as (DATEADD(dd, Validity, RechargedOn)),
    [NewConsumer138314Mobile_Number] bigint  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Mobile_Number] in table 'NewConsumer138314'
ALTER TABLE [dbo].[NewConsumer138314]
ADD CONSTRAINT [PK_NewConsumer138314]
    PRIMARY KEY CLUSTERED ([Mobile_Number] ASC);
GO

-- Creating primary key on [RechargeID] in table 'NewRecharge138314'
ALTER TABLE [dbo].[NewRecharge138314]
ADD CONSTRAINT [PK_NewRecharge138314]
    PRIMARY KEY CLUSTERED ([RechargeID] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [NewConsumer138314Mobile_Number] in table 'NewRecharge138314'
ALTER TABLE [dbo].[NewRecharge138314]
ADD CONSTRAINT [FK_NewConsumer138314NewRecharge138314]
    FOREIGN KEY ([NewConsumer138314Mobile_Number])
    REFERENCES [dbo].[NewConsumer138314]
        ([Mobile_Number])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_NewConsumer138314NewRecharge138314'
CREATE INDEX [IX_FK_NewConsumer138314NewRecharge138314]
ON [dbo].[NewRecharge138314]
    ([NewConsumer138314Mobile_Number]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------
select * from NewConsumer138314