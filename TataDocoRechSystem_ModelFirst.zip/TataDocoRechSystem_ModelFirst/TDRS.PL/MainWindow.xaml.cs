﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TDRS.BL;
using TDRS.Exceptions;
using TDRS.Entity;
namespace TDRS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        NewRecharge138314 r = new NewRecharge138314();
       
        private void btnVerify_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                NewConsumer138314 con = new NewConsumer138314();
                con = TDRSValidations.SearchConsumer( Convert.ToInt64(txtboxMobNo.Text));
                gridConsumer.DataContext = con;
                txtboxConsName.Visibility = Visibility.Visible;
                txtboxRegion.Visibility = Visibility.Visible;
            }
            catch(TDRSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       
        private void rbtn1_Checked(object sender, RoutedEventArgs e)
        {
            r.Amount =Convert.ToDouble( txtAmt1.Text);
            r.Data = txtData1.Text;
            r.Validity =Convert.ToInt32( txtVal1.Text);
            r.TalkTime = txtTalk1.Text;
            r.NewConsumer138314Mobile_Number = Convert.ToInt64(txtboxMobNo.Text);
            r.RechargedOn = DateTime.Today;
        }
        private void rbtn2_Checked(object sender, RoutedEventArgs e)
        {
            r.Amount = Convert.ToDouble(txtAmt2.Text);
            r.Data = txtData2.Text;
            r.Validity = Convert.ToInt32(txtVal2.Text);
            r.TalkTime = txtTalk2.Text;
            r.NewConsumer138314Mobile_Number =Convert.ToInt64( txtboxMobNo.Text);
            r.RechargedOn = DateTime.Today;
            
        }
        private void btnRecharge_Click(object sender, RoutedEventArgs e)
        {
           try
            {
                int records = TDRSValidations.AddRecharge(r);

                if (records > 0)
                {
                    MessageBox.Show("Recharge successfull!");
                    
                }
                else
                    throw new TDRSException ("Record not added");
            }
            catch (TDRSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        }

       
    }

