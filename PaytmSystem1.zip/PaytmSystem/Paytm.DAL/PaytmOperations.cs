﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paytm.Entity;
using Paytm.Exception;
using System.Data.SqlClient;

namespace Paytm.DAL
{
    public class PaytmOperations
    {
        static PaytmModelContainer1 context = new PaytmModelContainer1();

        public static int AddRecharge(Recharge_138252 r)
        {
            int records = 0;

            try
            {
                context.Recharge_138252.Add(r);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

         public static Consumer_138252 SearchConsumer(Int64 scode)
        {
            Consumer_138252 stud = null;

            try 
            {
               
                stud = (from s in context.Consumer_138252
                        where s.Mobile_Number ==scode
                        select s).FirstOrDefault();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        //public static List<Recharge_138252> GetAllRecharge()
        //{
        //    List<Recharge_138252> rechList = null;

        //    try 
        //    {
        //        rechList = context.Recharge_138252.ToList<Recharge_138252>();
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return rechList;
        //}
    
    }
}
