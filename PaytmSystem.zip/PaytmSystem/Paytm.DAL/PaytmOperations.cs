﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paytm.Entity;
using Paytm.Exception;
using System.Data.SqlClient;

namespace Paytm.DAL
{
    public class PaytmOperations
    {
        static PaytmModelContainer context = new PaytmModelContainer();

        public static int AddRecharge(RechargeDetails_138251 r)
        {
            int records = 0;

            try
            {
                context.RechargeDetails_138251.Add(r);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

         public static Consumer_138251 SearchConsumer(string scode)
        {
            Consumer_138251 stud = null;

            try 
            {
                stud = (from s in context.Consumer_138251
                        where s.Mobile_Number == scode
                        select s).FirstOrDefault();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        //public static List<RechargeDetails_138251> GetAllRecharge()
        //{
        //    List<RechargeDetails_138251> rechList = null;

        //    try 
        //    {
        //        rechList = context.RechargeDetails_138251.ToList<RechargeDetails_138251>();
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return rechList;
        //}
    
    }
}
