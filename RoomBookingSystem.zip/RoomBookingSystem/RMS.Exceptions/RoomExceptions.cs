﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Description : Exceptions Layer    
/// Employee ID :138319
/// Employee Name : Emil Biju N
/// Date of Creation : 6-Nov-2017
/// </summary>
namespace RMS.Exceptions
{
    public class RoomExceptions:ApplicationException
    {
        public RoomExceptions() : base()
        {
                
        }

        public RoomExceptions(string message)
            :base (message)
        {

        }
    }
}
