﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TDRS.Entity;
using TDRS.Exceptions;

namespace TDRS.DAL
{
    public class TDRSOperations
    {
        static TDRSModelContainer1 context = new TDRSModelContainer1();

        public static int AddRecharge(NewRecharge138314 r)
        {
            int records = 0;

            try
            {
                context.NewRecharge138314.Add(r);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static NewConsumer138314 SearchConsumer(Int64 mno)
        {
            NewConsumer138314 con = null;

            try
            {
                con = (from s in context.NewConsumer138314
                       where s.Mobile_Number == mno
                       select s

                    ).FirstOrDefault();
                return con;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
           

        }
    }
}
